import os
from dotenv import load_dotenv
import pinecone
from sentence_transformers import SentenceTransformer

load_dotenv()
api_key = os.getenv("PINECONE_API_KEY")
environment = os.getenv("PINECONE_ENVIRONMENT")
index_name = os.getenv("PINECONE_INDEX_NAME")

pinecone.init(api_key=api_key, environment=environment)

if index_name not in pinecone.list_indexes():
    pinecone.create_index(name=index_name, dimension=384)

index = pinecone.Index(index_name)
embed_model = SentenceTransformer('all-MiniLM-L6-v2')

def add_document(doc_id, text):
    embedding = embed_model.encode(text).tolist()
    index.upsert([(doc_id, embedding, {"text": text})])

def search_document(query, top_k=3):
    query_emb = embed_model.encode(query).tolist()
    results = index.query(query_emb, top_k=top_k, include_metadata=True)
    return [match['metadata']['text'] for match in results['matches']]
