def summarize_text(text):
    return f"[Summary]: {text[:100]}..."
