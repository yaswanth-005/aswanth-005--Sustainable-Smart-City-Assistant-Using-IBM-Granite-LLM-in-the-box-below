import streamlit as st
from pinecone_integration import add_document, search_document
from granite_mock import summarize_text

st.title("🧠 Smart City Policy Assistant")
menu = st.sidebar.selectbox("Choose Action", ["Upload & Index", "Search & Summarize"])

if menu == "Upload & Index":
    uploaded_file = st.file_uploader("Upload a policy document (TXT)", type="txt")
    if uploaded_file is not None:
        text = uploaded_file.read().decode("utf-8")
        doc_id = uploaded_file.name
        add_document(doc_id, text)
        st.success("Document indexed successfully!")

elif menu == "Search & Summarize":
    query = st.text_input("Ask a policy-related question:")
    if st.button("Search"):
        results = search_document(query)
        for i, res in enumerate(results):
            summary = summarize_text(res)
            st.markdown(f"### Result {i+1}")
            st.text_area("Summary", summary, height=150)
