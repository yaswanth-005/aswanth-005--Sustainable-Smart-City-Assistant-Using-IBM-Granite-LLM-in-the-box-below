# Sustainable Smart City Assistant

An AI-powered assistant for urban sustainability using IBM Granite LLM, Pinecone, FastAPI, and Streamlit.

## Features

- Policy summarization
- Citizen feedback logging
- KPI forecasting
- Eco tips generator
- Anomaly detection
- Semantic document search

## Tech Stack

- IBM Watsonx Granite LLM
- Pinecone vector DB
- FastAPI + Streamlit
- Linear Regression for forecasting
- SentenceTransformer for embeddings

## How to Run

1. Install dependencies: `pip install -r requirements.txt`
2. Add your `.env` file with Pinecone credentials
3. Run: `streamlit run src/app.py`

## Folder Structure

- `src/`: source code
- `models/`: saved ML models
- `data/`: sample datasets
- `docs/`: project report PDF
